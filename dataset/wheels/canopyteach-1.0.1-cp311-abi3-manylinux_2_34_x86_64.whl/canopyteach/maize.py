"""Leaf geometry port of the LOCAL con_plant4 in the supplied fspm_run_v3.m.

Width controls, adaptive axial sampling, discrete midrib, cycloid edge sag and
area threshold follow that source. SI units replace centimetres. The caller
passes explicit wave parameters, avoiding MATLAB/NumPy RNG equivalence claims.
"""
import numpy as np

def pchip(x,y,t):
    """Shape-preserving piecewise cubic Hermite interpolation (no SciPy needed)."""
    x=np.asarray(x,dtype=float);y=np.asarray(y,dtype=float);t=np.asarray(t,dtype=float)
    h=np.diff(x);s=np.diff(y)/h;m=np.zeros_like(y)
    if len(x)<3 or np.any(h<=0): raise ValueError('at least three increasing knots required')
    for k in range(1,len(x)-1):
        if s[k-1]*s[k]>0:
            a=2*h[k]+h[k-1];b=h[k]+2*h[k-1]
            m[k]=(a+b)/(a/s[k-1]+b/s[k])
    def endpoint(h0,h1,s0,s1):
        value=((2*h0+h1)*s0-h0*s1)/(h0+h1)
        if np.sign(value)!=np.sign(s0): return 0.
        if np.sign(s0)!=np.sign(s1) and abs(value)>3*abs(s0):return 3*s0
        return value
    m[0]=endpoint(h[0],h[1],s[0],s[1]);m[-1]=endpoint(h[-1],h[-2],s[-1],s[-2])
    j=np.clip(np.searchsorted(x,t,side='right')-1,0,len(x)-2);u=(t-x[j])/h[j]
    return ((2*u**3-3*u**2+1)*y[j]+(u**3-2*u**2+u)*h[j]*m[j]
            +(-2*u**3+3*u**2)*y[j+1]+(u**3-u**2)*h[j]*m[j+1])

def width_controls():
    # Original x is measured from tip. The generator flips these five samples.
    x=np.linspace(0,1,5);lm=.619;cm=.788
    return (-x*(x-2*lm)/lm**2)**cm

def maize_leaf(length=.65,width=.12,curvature=70.,angle=30.,azimuth=0.,
               mesh_step=.03,wave_amplitude=2.,wave_cycles=5,border_exp=1.6,
               min_area=2e-5,return_details=False):
    """angle is the base-to-quarter-midrib elevation above horizontal (degrees).
    curvature is the source's discrete total turn parameter, in degrees.
    min_area=0.2 cm2 in the source. mesh_step=3 cm. NoiseAmp remains zero.
    """
    numbers=[length,width,curvature,angle,azimuth,mesh_step,wave_amplitude,wave_cycles,border_exp,min_area]
    if not np.isfinite(numbers).all() or min(length,width,mesh_step)<=0 or not 0<=curvature<=140 or not 0<=angle<=85 or wave_amplitude<0 or int(wave_cycles)!=wave_cycles or wave_cycles<1 or border_exp<0 or min_area<0:
        raise ValueError('invalid maize leaf parameter')
    if mesh_step>length/4:raise ValueError('mesh_step must be <= leaf_length/4 for the quarter-midrib angle')
    axis=[0.]
    while axis[-1]<length-1e-12:
        step=mesh_step*(1+3*np.exp(-axis[-1]/length*4))
        axis.append(min(axis[-1]+step,length))
    axis=np.asarray(axis)
    half=np.maximum(pchip(np.linspace(0,length,5),width*width_controls()[::-1]/2,axis),0)
    turn=np.deg2rad(curvature)/(len(axis)-1)
    a=turn*np.arange(len(axis)-1);dl=np.diff(axis)
    x=np.r_[0,np.cumsum(dl*np.sin(a))];z=np.r_[0,np.cumsum(dl*np.cos(a))]
    wave=wave_amplitude*.5*(1+np.sin(2*np.pi*wave_cycles*axis/length))
    sag=half*(1-np.cos(wave))/np.maximum(wave,np.finfo(float).eps)
    nw=np.maximum(1,np.floor(half/(2*mesh_step)).astype(int))
    vertices=[];starts=[]
    for k,h in enumerate(half):
        starts.append(len(vertices))
        for f in np.linspace(0,1,nw[k]+1):
            clean=sag[k]*f**border_exp if h>=1e-12 else 0.
            vertices.append([x[k],f*h,z[k]+max(clean,-.4*h)])
    faces=[]
    for k in range(len(axis)-1):
        count=max(nw[k],nw[k+1])
        # MATLAB round for nonnegative coordinates is floor(x+0.5).
        i=np.floor(np.linspace(0,nw[k],count+1)+.5).astype(int)+starts[k]
        j=np.floor(np.linspace(0,nw[k+1],count+1)+.5).astype(int)+starts[k+1]
        for q in range(count):faces.extend([[i[q],j[q],i[q+1]],[j[q],j[q+1],i[q+1]]])
    right=np.asarray(vertices);faces=np.asarray(faces,dtype=np.int32)
    left=right.copy();left[:,1]*=-1
    v=np.vstack([right,left]);f=np.vstack([faces,faces[:,[0,2,1]]+len(right)])
    t=v[f];area=np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)/2
    # Rigid rotation cannot change area; filter before rotation for reproducibility.
    f=f[area>=max(min_area,1e-16)]
    if not len(f):raise ValueError('leaf smaller than the source area threshold')
    quarter=int(np.argmin(abs(axis-.25*length)))
    theta=np.arctan2(x[quarter],z[quarter])
    beta=min(np.deg2rad(90-angle),np.pi/2-1e-6);delta=beta-theta
    ry=np.array([[np.cos(delta),0,np.sin(delta)],[0,1,0],[-np.sin(delta),0,np.cos(delta)]])
    psi=np.deg2rad(azimuth);rz=np.array([[np.cos(psi),-np.sin(psi),0],[np.sin(psi),np.cos(psi),0],[0,0,1.]])
    v=v@(rz@ry).T
    used,indices=np.unique(f,return_inverse=True);f=indices.reshape(-1,3).astype(np.int32);v=v[used]
    if return_details:
        mid=np.c_[x,np.zeros(len(x)),z]@(rz@ry).T
        return v,f,dict(axis=axis,half_width=half,midrib=mid,quarter_index=quarter,
            source_stem_angle_deg=90-angle,wave_amplitude=wave_amplitude,wave_cycles=int(wave_cycles),
            curvature_deg=curvature,mesh_step_m=mesh_step,min_area_m2=min_area)
    return v,f
