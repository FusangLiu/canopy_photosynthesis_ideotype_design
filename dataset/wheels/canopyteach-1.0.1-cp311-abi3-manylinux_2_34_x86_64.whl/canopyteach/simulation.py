from dataclasses import dataclass,replace
import numpy as np
from .geometry import Architecture,make_canopy,plant_azimuth_grid
from .periodic import crop_center
from .light import CanopyLight
from .solar import solar_position
from .photosynthesis import Physiology,assimilation

def integrate(y,x,axis=0):
    y=np.asarray(y);x=np.asarray(x);dy=np.diff(x)
    a=np.take(y,np.arange(len(x)-1),axis=axis);b=np.take(y,np.arange(1,len(x)),axis=axis)
    shape=[1]*y.ndim;shape[axis]=len(dy)
    return np.sum((a+b)*.5*dy.reshape(shape),axis=axis)

@dataclass
class DayResult:
    mesh: object
    hours: np.ndarray
    sun: np.ndarray
    direct_normal: np.ndarray
    ppfd: np.ndarray
    net_a: np.ndarray
    canopy_a_ground: np.ndarray
    daily_light_leaf: np.ndarray
    daily_carbon_leaf: np.ndarray
    summary: dict
    statistics: list

def prepare_canopy(config=None,*,top=2.4,buffer=None):
    c=config or Architecture()
    if c.staggered and c.rows%2:raise ValueError('staggered periodic center requires an even number of rows')
    if abs(c.row_rotation%180)>1e-10:raise ValueError('central classroom crop is row-aligned; use row_rotation=0 or 180')
    reach=c.leaf_length+c.leaf_width/2+c.stem_radius
    minimum=max(1,int(np.ceil(reach/min(c.dx,c.dy)-.5)))
    if buffer is None:buffer=minimum
    if isinstance(buffer,bool) or int(buffer)!=buffer or buffer<minimum:
        raise ValueError(f'buffer must be an integer >= {minimum} to cover possible entering leaves')
    buffer=int(buffer);outer=replace(c,rows=c.rows+2*buffer,columns=c.columns+2*buffer)
    if outer.rows*outer.columns>10000:raise ValueError('large-stand buffer exceeds the classroom size limit')
    # Repeat the SAME central-cell orientation field into the source buffer.
    # Independent buffer randomization would make opposite edges inconsistent.
    source=make_canopy(outer,azimuth_period=(c.rows,c.columns),azimuth_offset=(buffer,buffer))
    lx=c.columns*c.dx;ly=c.rows*c.dy
    result=crop_center(source,(-lx/2,lx/2,-ly/2,ly/2,0.,top))
    expected=float(source.area[source.leaf_mask].sum()*c.rows*c.columns/(outer.rows*outer.columns))
    if not np.isclose(result.report['prepared_leaf_area_m2'],expected,rtol=1e-10,atol=1e-12):
        raise ArithmeticError('central crop leaf area differs from regular-stand density; inspect crop layout')
    result.report.update(source_rows=outer.rows,source_columns=outer.columns,central_rows=c.rows,central_columns=c.columns,
        buffer_rows_each_side=buffer,buffer_columns_each_side=buffer,conservative_leaf_reach_m=reach,
        minimum_omitted_stem_distance_m=(buffer+.5)*min(c.dx,c.dy),expected_center_leaf_area_m2=expected,
        central_leaf_area_error_m2=result.report['prepared_leaf_area_m2']-expected)
    result.report.update(plant_azimuth_mode=c.plant_azimuth_mode,plant_azimuth_seed=c.seed,
        central_plant_azimuth_degrees=plant_azimuth_grid(c).tolist(),
        buffer_orientation='periodic repetition of the central-cell whole-plant angles; within-plant phyllotaxis retained')
    return result

def simulate_day(config=None,*,date='2026-06-21',latitude=31.,longitude=121.,utc_offset=8.,
                 step_minutes=30,ray_spacing=.005,threads=4,direct_normal=1500.,physiology=None,top=2.4,buffer=None):
    if isinstance(step_minutes,bool) or int(step_minutes)!=step_minutes or not 1<=step_minutes<=120 or 1440%step_minutes:
        raise ValueError('step_minutes must divide 1440 and be between 1 and 120')
    if not np.isfinite(direct_normal) or direct_normal<0:raise ValueError('invalid direct_normal')
    c=config or Architecture();mesh=prepare_canopy(c,top=top,buffer=buffer);tracer=CanopyLight(mesh,ray_spacing=ray_spacing,threads=threads)
    p=physiology or Physiology();hours=np.linspace(0,24,1440//step_minutes+1)
    q=np.zeros((len(hours),len(mesh.faces)));sun=[];dni=[];stats=[]
    for i,h in enumerate(hours):
        sp=solar_position(date,h,latitude,longitude,utc_offset);sun.append(sp['sun'])
        d=direct_normal if sp['sun'][2]>0 else 0.;dni.append(d)
        r=tracer.trace(sp['sun'],d);q[i]=r.total;stats.append(r.stats)
    net=np.zeros_like(q);mask=mesh.leaf_mask;net[:,mask]=assimilation(q[:,mask],p)
    area=mesh.area;canopy=net@area/mesh.ground_area
    light_daily=integrate(q,hours*3600)*1e-6;carbon_daily=integrate(net,hours*3600)*1e-6
    photons=float(light_daily[mask]@area[mask]/mesh.ground_area)
    incoming=integrate([s['incident_umol_s'] for s in stats],hours*3600)*1e-6/mesh.ground_area
    stem_photons=integrate([s['stem_umol_s'] for s in stats],hours*3600)*1e-6/mesh.ground_area
    escape=integrate([s['escape_umol_s'] for s in stats],hours*3600)*1e-6/mesh.ground_area
    summary=dict(daily_net_mol_co2_m2_ground=float(integrate(canopy,hours*3600)*1e-6),
        daily_leaf_intercepted_mol_photons_m2_ground=photons,daily_stem_intercepted_mol_photons_m2_ground=float(stem_photons),
        daily_escape_mol_photons_m2_ground=float(escape),daily_incident_mol_photons_m2_ground=float(incoming),
        daily_leaf_interception_fraction=photons/incoming if incoming else 0.,lai=mesh.lai,
        leaf_area_m2=float(area[mask].sum()),ground_area_m2=mesh.ground_area,
        date=str(date),latitude=float(latitude),longitude=float(longitude),utc_offset=float(utc_offset),
        step_minutes=int(step_minutes),ray_spacing_m=float(ray_spacing),threads_used=max(s['threads_used'] for s in stats),
        boundary='periodic_xy',weighting='energy',domain=list(mesh.domain),
        light_scope='direct only; zero reflectance/transmittance; no sky diffuse or secondary scattering',
        weather='synthetic constant daytime DNI, zero below geometric horizon; not measured or calibrated weather',
        direct_normal_daytime=float(direct_normal),
        carbon_scope='24h leaf net assimilation including leaf dark respiration; stem/root respiration excluded',
        data_status='synthetic maize architecture and radiation; numerical verification, no field validation',
        periodic_geometry=mesh.report)
    if not np.isclose(photons+stem_photons+escape,incoming,rtol=2e-10,atol=1e-10):raise ArithmeticError('daily photon ledger failed')
    return DayResult(mesh,hours,np.asarray(sun),np.asarray(dni),q,net,canopy,light_daily,carbon_daily,summary,stats)

def compare_structures(configs,**kwargs):
    result={name:simulate_day(c,**kwargs) for name,c in configs.items()}
    areas=[r.summary['leaf_area_m2'] for r in result.values()]
    if not np.allclose(areas,areas[0],rtol=1e-10,atol=1e-12):raise ValueError('structure comparison requires equal leaf area')
    return result

def angle_search(base=None,lower=(10,35,60),upper=(25,55,80),**kwargs):
    base=base or Architecture();records=[]
    for a in lower:
        for b in upper:
            r=simulate_day(replace(base,lower_angle=float(a),upper_angle=float(b)),**kwargs)
            records.append(dict(lower_angle=float(a),upper_angle=float(b),**r.summary))
    return sorted(records,key=lambda r:r['daily_net_mol_co2_m2_ground'],reverse=True)
