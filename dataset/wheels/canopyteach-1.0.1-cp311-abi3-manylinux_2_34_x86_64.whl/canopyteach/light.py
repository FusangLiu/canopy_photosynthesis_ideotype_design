"""One selected classroom model: periodic XY + energy packets + direct light."""
from dataclasses import dataclass
import numpy as np
from canopyteach.raytracing import Scene
from .geometry import LEAF,STEM

@dataclass
class LightResult:
    total: np.ndarray
    area: np.ndarray
    fractions: dict
    stats: dict

class CanopyLight:
    def __init__(self,prepared,*,ray_spacing=.005,threads=4):
        self.prepared=prepared;self.domain=prepared.domain
        if not np.isfinite(ray_spacing) or ray_spacing<=0:raise ValueError('ray_spacing must be positive')
        b=np.asarray(self.domain);nx=int(np.ceil((b[1]-b[0])/ray_spacing));ny=int(np.ceil((b[3]-b[2])/ray_spacing))
        if nx*ny>10000000:raise ValueError('too many top raster rays; increase ray_spacing')
        self.pixel_area=(b[1]-b[0])*(b[3]-b[2])/(nx*ny)
        x=b[0]+(np.arange(nx)+.5)*(b[1]-b[0])/nx;y=b[2]+(np.arange(ny)+.5)*(b[3]-b[2])/ny
        xx,yy=np.meshgrid(x,y);self.origins=np.c_[xx.ravel(),yy.ravel(),np.full(xx.size,b[5])]
        self.scene=Scene(prepared.vertices,prepared.faces,precision=32);self.threads=threads
        self.ray_spacing=ray_spacing

    def trace(self,sun,direct_normal=1500.):
        sun=np.asarray(sun,dtype=float)
        if sun.shape!=(3,) or not np.isfinite(sun).all() or np.linalg.norm(sun)==0 or not np.isfinite(direct_normal) or direct_normal<0:
            raise ValueError('invalid sun or irradiance')
        sun=sun/np.linalg.norm(sun)
        if sun[2]<=0 or direct_normal==0:
            return LightResult(np.zeros(len(self.prepared.faces)),self.prepared.area,
                {'leaf':0.,'stem':0.,'escape':1.},dict(incident_umol_s=0.,leaf_umol_s=0.,stem_umol_s=0.,escape_umol_s=0.,
                    threads_used=0,rays=0,wraps=0,boundary='periodic_xy',weighting='energy'))
        # Horizontal aperture: e = DNI * sin(elevation) * horizontal pixel area.
        energy=float(direct_normal*sun[2]*self.pixel_area)
        r=self.scene.trace(self.origins,-sun,energy,False,threads=self.threads,
            boundary='periodic_xy',domain=self.domain,weighting='energy')
        ids=r.hits.indices;hit=ids>=0;org=np.zeros(len(ids),dtype=np.int8);org[hit]=self.prepared.organ[ids[hit]]
        counts={name:int(np.sum(org==kind)) for name,kind in [('leaf',LEAF),('stem',STEM),('escape',0)]}
        fractions={name:count/len(ids) for name,count in counts.items()}
        st=dict(incident_umol_s=len(ids)*energy,leaf_umol_s=counts['leaf']*energy,
            stem_umol_s=counts['stem']*energy,escape_umol_s=counts['escape']*energy,
            threads_used=r.stats['primary']['threads_used'],rays=len(ids),wraps=int(r.hits.wraps.sum()),
            boundary='periodic_xy',weighting='energy',native=r.stats)
        if not np.isclose(r.total@r.area,st['leaf_umol_s']+st['stem_umol_s'],rtol=2e-10,atol=1e-10):
            raise ArithmeticError('native per-face energy sum failed to close')
        return LightResult(r.total,self.prepared.area,fractions,st)
