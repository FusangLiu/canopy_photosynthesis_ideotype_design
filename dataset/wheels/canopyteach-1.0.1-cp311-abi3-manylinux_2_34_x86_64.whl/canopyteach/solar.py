"""NOAA fractional-year approximation; geometric sun, no atmospheric refraction.
Axes: x=east, y=north, z=up. Solar azimuth: clockwise from north.
Clock hours use fixed UTC offset (standard time); DST must be removed by caller.
"""
from datetime import date as Date
import calendar
import numpy as np

def solar_position(date='2026-06-21',hour=12.,latitude=31.,longitude=121.,utc_offset=8.):
    date=Date.fromisoformat(str(date))
    if not np.isfinite([hour,latitude,longitude,utc_offset]).all() or not 0<=hour<=24 or not -90<=latitude<=90 or not -180<=longitude<=180 or not -14<=utc_offset<=14:
        raise ValueError('invalid clock/location inputs')
    n=date.timetuple().tm_yday;days=366 if calendar.isleap(date.year) else 365
    g=2*np.pi/days*(n-1+(hour-12)/24)
    eot=229.18*(.000075+.001868*np.cos(g)-.032077*np.sin(g)-.014615*np.cos(2*g)-.040849*np.sin(2*g))
    dec=.006918-.399912*np.cos(g)+.070257*np.sin(g)-.006758*np.cos(2*g)+.000907*np.sin(2*g)-.002697*np.cos(3*g)+.00148*np.sin(3*g)
    correction=eot+4*longitude-60*utc_offset
    solar_hour=hour+correction/60
    h=np.deg2rad(15*(solar_hour-12));phi=np.deg2rad(latitude)
    sun=np.array([-np.cos(dec)*np.sin(h),
        np.cos(phi)*np.sin(dec)-np.sin(phi)*np.cos(dec)*np.cos(h),
        np.sin(phi)*np.sin(dec)+np.cos(phi)*np.cos(dec)*np.cos(h)])
    return dict(sun=sun,elevation_deg=float(np.rad2deg(np.arcsin(np.clip(sun[2],-1,1)))),
        azimuth_deg=float(np.rad2deg(np.arctan2(sun[0],sun[1]))%360),solar_hour=float(solar_hour),
        correction_minutes=float(correction),equation_of_time_minutes=float(eot),declination_deg=float(np.rad2deg(dec)))

def synthetic_weather(elevation_deg,scenario='clear'):
    """Synthetic PPFD drivers, NOT a calibrated clear-sky or measured weather model.
    The elevation scales ground-horizontal global PPFD; DNI is normal to sun.
    Clear/cloudy have the same daily incident photon total by design, isolating
    direct/diffuse partition effects. No cloud-driven loss is implied.
    """
    if scenario not in ('clear','diffuse'): raise ValueError('scenario must be clear or diffuse')
    z=max(0.,float(np.sin(np.deg2rad(elevation_deg))))
    if z<=0: return 0.,0.
    global_horizontal=1700*z
    fraction=.15 if scenario=='clear' else .85
    return (1-fraction)*global_horizontal/z,fraction*global_horizontal

