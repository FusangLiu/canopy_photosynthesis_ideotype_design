"""Forward C/OpenMP ray tracing, original RG optics and explicit XY periodicity."""
from dataclasses import dataclass
import time
import numpy as np
from . import _core
__version__='0.1.0'

def _integer(value,name,lo,hi):
    if isinstance(value,(bool,np.bool_)) or int(value)!=value or not lo<=value<=hi:
        raise ValueError(f'{name} must be an integer in [{lo},{hi}]')
    return int(value)

def _vectors(x,name):
    a=np.ascontiguousarray(x,dtype=np.float64)
    if a.ndim!=2 or a.shape[1]!=3 or not np.isfinite(a).all():
        raise ValueError(f'{name} must be finite Nx3')
    return a

def _rays(origins,directions):
    o=_vectors(origins,'origins');d=np.asarray(directions,dtype=np.float64)
    if d.shape==(3,):d=np.broadcast_to(d,o.shape)
    d=_vectors(d,'directions')
    if d.shape!=o.shape or np.any(np.linalg.norm(d,axis=1)==0):
        raise ValueError('directions must match origins and be nonzero')
    return o,d

@dataclass
class Hits:
    indices: np.ndarray
    t: np.ndarray
    points: np.ndarray
    wraps: np.ndarray
    stats: dict
    @property
    def hit(self):return self.indices>=0

@dataclass
class LightResult:
    total: np.ndarray
    direct: np.ndarray
    scattered: np.ndarray
    area: np.ndarray
    hits: Hits
    stats: dict
    @property
    def light_ratio_all(self):return self.total
    @property
    def mesh_hit_ray_energy_diff_ratio(self):return self.scattered

class Scene:
    """Immutable native BVH. Mesh is copied on construction.

    Vertices Nx3; faces Mx3, Python zero-based by default. `precision=32`
    uses CUDA float32 intersection/point arithmetic and its absolute 1e-6
    determinant and t thresholds. `precision=64` is an explicit alternative.
    Directions are NOT normalized in the intersection query; t is a parameter.
    """
    def __init__(self,vertices,faces,*,index_base=0,precision=32):
        start=time.perf_counter();v=_vectors(vertices,'vertices');f=np.asarray(faces)
        if f.ndim!=2 or f.shape[1]!=3 or not np.isfinite(f).all() or not np.equal(f,np.floor(f)).all():
            raise ValueError('faces must be integer Mx3')
        if index_base not in (0,1):raise ValueError('index_base must be 0 or 1')
        f=f.astype(np.int64)-index_base
        if f.size and (f.min()<0 or f.max()>=len(v) or f.max()>np.iinfo(np.int32).max):
            raise ValueError('face index out of range')
        if precision not in (32,64):raise ValueError('precision must be 32 or 64')
        self._capsule=_core.build(v,np.ascontiguousarray(f,dtype=np.int32),precision)
        g=np.frombuffer(_core.geometry(self._capsule),dtype=np.float64).reshape(-1,4)
        self._area=g[:,0].copy();self._normals=g[:,1:].copy();self.precision=precision
        self.build_seconds=time.perf_counter()-start
    @property
    def area(self):return self._area.copy()
    @property
    def normals(self):return self._normals.copy()

    def first_hits(self,origins,directions,*,threads=0,boundary='open',domain=None,max_wraps=10000):
        o,d=_rays(origins,directions);threads=_integer(threads,'threads',0,256)
        if boundary not in ('open','periodic_xy'):raise ValueError("boundary must be 'open' or 'periodic_xy'")
        if boundary=='periodic_xy':
            if domain is None:raise ValueError('periodic_xy requires domain=(xmin,xmax,ymin,ymax,zmin,zmax)')
            b=np.ascontiguousarray(domain,dtype=np.float64)
            if b.shape!=(6,) or not np.isfinite(b).all() or np.any(b[1::2]<=b[::2]):raise ValueError('invalid domain')
        else:b=np.zeros(6,dtype=np.float64)
        max_wraps=_integer(max_wraps,'max_wraps',1,10000000)
        ids,t,p,w,st=_core.hits(self._capsule,o,d,threads,int(boundary=='periodic_xy'),b,max_wraps)
        st.update(boundary=boundary,precision=self.precision)
        return Hits(np.frombuffer(ids,dtype=np.int32).copy(),np.frombuffer(t,dtype=np.float64).copy(),
                    np.frombuffer(p,dtype=np.float64).reshape(-1,3).copy(),np.frombuffer(w,dtype=np.int32).copy(),st)

    def accumulate(self,indices,directions,energy,*,weighting='legacy_cosine',threads=0):
        ids=np.asarray(indices)
        if ids.ndim!=1 or not np.isfinite(ids).all() or not np.equal(ids,np.floor(ids)).all() or np.any(ids < -1) or np.any(ids>=len(self._area)):
            raise ValueError('invalid first-hit face IDs')
        ids=np.ascontiguousarray(ids,dtype=np.int32);d=_vectors(directions,'directions')
        en=np.ascontiguousarray(np.broadcast_to(np.asarray(energy,dtype=np.float64),(len(ids),)))
        if len(d)!=len(ids) or not np.isfinite(en).all() or np.any(en<0):raise ValueError('invalid direction/energy shape or values')
        if weighting not in ('legacy_cosine','energy'):raise ValueError('unknown weighting')
        raw,st=_core.accumulate(self._capsule,ids,d,en,int(weighting=='legacy_cosine'),_integer(threads,'threads',0,256))
        return np.frombuffer(raw,dtype=np.float64).copy(),st

    def trace(self,origins,directions,ray_energy,diffuse=False,*,threads=0,
              boundary='open',domain=None,max_wraps=10000,weighting='legacy_cosine',
              seed=20261025,uniforms=None,secondary_rays=None):
        """Native forward first hits -> original cosine/area -> optional one bounce.

        diffuse=True retains the original 0.2 ratio, 25 BRDF samples/hit,
        global-Z mirror, division by 2 and 0.8 direct retention. It is NOT
        diffuse sky radiation. `uniforms` optionally fixes all 2D random samples.
        `secondary_rays=(origins,dirs,energy)` accepts UNMIRRORED original MEX
        outputs, for exact common-ray validation. No additional scene offset.
        weighting='energy' explicitly removes the original extra cosine;
        use it for a conventional forward packet / fastTracer comparison.
        """
        start=time.perf_counter();o,d=_rays(origins,directions)
        if np.ndim(ray_energy)!=0 or not np.isfinite(ray_energy) or ray_energy<0:raise ValueError('ray_energy must be a nonnegative scalar')
        if diffuse not in (False,True,0,1):raise ValueError('diffuse must be 0 or 1')
        h=self.first_hits(o,d,threads=threads,boundary=boundary,domain=domain,max_wraps=max_wraps)
        direct,acc=self.accumulate(h.indices,d,float(ray_energy),weighting=weighting,threads=threads)
        scattered=np.zeros_like(direct);st={'primary':h.stats,'accumulation':acc,'weighting':weighting,'build_seconds':self.build_seconds}
        if diffuse and np.any(h.hit):
            if secondary_rays is None:
                so,sd,se,ss=scatter_samples(h.points[h.hit],d[h.hit],self._normals[h.indices[h.hit]],float(ray_energy),
                    seed=seed,uniforms=uniforms,threads=threads)
                ss['source']='Port of readable diffuse_all.m + cook_torrance_brdf_rs.m; original diffuse_all2_mex differs slightly'
                st['scatter_generation']=ss
            else:
                so,sd=_rays(secondary_rays[0],secondary_rays[1]);se=np.asarray(secondary_rays[2],dtype=np.float64)
                if se.shape!=(len(so),) or len(so)!=int(np.sum(h.hit))*25:raise ValueError('secondary_rays must contain 25 samples per primary hit')
                st['scatter_generation']={'source':'external common rays; original MEX fixture'}
            mirrored=sd.copy();mirrored[:,2]*=-1
            so=np.ascontiguousarray(np.concatenate((so,so)));sd=np.ascontiguousarray(np.concatenate((sd,mirrored)))
            se=np.ascontiguousarray(np.concatenate((se,se))*.5)
            sh=self.first_hits(so,sd,threads=threads,boundary=boundary,domain=domain,max_wraps=max_wraps)
            scattered,sa=self.accumulate(sh.indices,sd,se,weighting=weighting,threads=threads)
            st.update(secondary=sh.stats,secondary_accumulation=sa,
                secondary_hit_count=int(sh.hit.sum()),secondary_wrap_count=int(sh.wraps.sum()))
        total=.8*direct+scattered if diffuse else direct.copy()
        st.update(total_seconds=time.perf_counter()-start,primary_hit_count=int(h.hit.sum()),
                  primary_wrap_count=int(h.wraps.sum()),diffuse=bool(diffuse),seed=seed,
                  boundary=boundary,domain=None if domain is None else list(domain))
        st['packet_ledger']={'incident':float(len(o)*ray_energy),'primary_hit':float(h.hit.sum()*ray_energy),
            'primary_escape':float((len(o)-h.hit.sum())*ray_energy),
            'face_direct_after_weighting':float(direct@self._area),'face_total_after_weighting':float(total@self._area),
            'note':'Energy per time if ray_energy is umol/s. Legacy cosine changes packet accounting; energy mode preserves it.'}
        if diffuse and np.any(h.hit):
            st['packet_ledger'].update(secondary_emitted=float(se.sum()),secondary_hit=float(se[sh.hit].sum()),secondary_escape=float(se[~sh.hit].sum()))
        return LightResult(total,direct,scattered,self.area,h,st)

def scatter_samples(points,incident,normals,ray_energy,*,seed=20261025,uniforms=None,threads=0,samples=25):
    p=_vectors(points,'points');L=_vectors(incident,'incident');N=_vectors(normals,'normals')
    if p.shape!=L.shape or L.shape!=N.shape:raise ValueError('scatter vectors must have same shape')
    samples=_integer(samples,'samples',1,100000)
    if uniforms is None:
        u=np.random.default_rng(seed).random((len(p),samples,2))
        # RNG has [0,1) range; the analytical BRDF is singular at endpoints.
        u=np.maximum(u,np.nextafter(0.,1.))
    else:u=np.asarray(uniforms,dtype=np.float64)
    if u.shape!=(len(p),samples,2):raise ValueError('uniforms must have shape (hits,samples,2)')
    v,e,st=_core.scatter(p,L,N,float(ray_energy),samples,np.ascontiguousarray(u),_integer(threads,'threads',0,256))
    return np.repeat(p,samples,axis=0),np.frombuffer(v,dtype=np.float64).reshape(-1,3).copy(),np.frombuffer(e,dtype=np.float64).copy(),st

def ray_tracing_rg_cpu(vertices,faces,orig,dir_ray,ray_energy,diffuse=0,visual=0,**kwargs):
    """Root MATLAB wrapper equivalent. Python zero-based faces by default.

    Default boundary is periodic_xy and requires an explicit domain. Use
    boundary='open' ONLY to compare with the original unmodified RG wrapper.
    `index_base=1` accepts MATLAB faces. Returns (total, scatter), with the
    original scalar 0 second output when diffuse=0. Use Scene.trace for details.
    """
    s=Scene(vertices,faces,index_base=kwargs.pop('index_base',0),precision=kwargs.pop('precision',32))
    kwargs.setdefault('boundary','periodic_xy')
    r=s.trace(orig,dir_ray,ray_energy,diffuse,**kwargs)
    if visual:
        import matplotlib.pyplot as plt
        plt.scatter(np.arange(len(r.total)),r.total,s=3);plt.xlabel('Face');plt.ylabel('PPFD');plt.show()
    return r.total,r.scattered if diffuse else 0

def solar_aperture(vertices,sun,*,direct_normal=1000.,step=.005,max_rays=10000000):
    """A deterministic sun-normal raster carrying DNI * cell area per ray.

    This helper is independent of the GPU wrapper's original custom light array.
    No edge clipping: the padded aperture covers the full projected AABB.
    """
    v=_vectors(vertices,'vertices');sun=np.asarray(sun,dtype=float)
    if not len(v) or sun.shape!=(3,) or not np.isfinite(sun).all() or not sun[2]>0 or not np.isfinite([step,direct_normal]).all() or step<=0 or direct_normal<0:raise ValueError('invalid aperture input')
    sun=sun/np.linalg.norm(sun);helper=np.array([0.,0,1.]) if sun[2]<.9 else np.array([0.,1.,0])
    a=np.cross(helper,sun);a/=np.linalg.norm(a);b=np.cross(sun,a)
    lo=v.min(0);hi=v.max(0);corners=np.array([[x,y,z] for x in [lo[0],hi[0]] for y in [lo[1],hi[1]] for z in [lo[2],hi[2]]])
    pa=corners@a;pb=corners@b;n=np.ceil([np.ptp(pa)/step,np.ptp(pb)/step]).astype(np.int64)+2
    if int(n[0])*int(n[1])>max_rays:raise ValueError('aperture exceeds max_rays; use larger step')
    x=pa.min()-step+(np.arange(n[0])+.5)*step;y=pb.min()-step+(np.arange(n[1])+.5)*step
    xx,yy=np.meshgrid(x,y,indexing='xy');origin=xx.ravel()[:,None]*a+yy.ravel()[:,None]*b+(np.max(corners@sun)+max(step,1e-4))*sun
    return np.ascontiguousarray(origin),np.broadcast_to(-sun,origin.shape).copy(),float(direct_normal*step*step)
