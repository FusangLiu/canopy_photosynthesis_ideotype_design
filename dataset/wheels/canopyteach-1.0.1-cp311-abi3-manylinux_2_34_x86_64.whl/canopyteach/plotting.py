import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from .geometry import LEAF,STEM,make_canopy,leaf,stem

def draw_mesh(ax,mesh,values=None,title='Maize canopy',cmap='viridis',vmin=0,vmax=None):
    if values is None:colors=np.array(['#3e9c63' if o==LEAF else '#99794f' for o in mesh.organ])
    else:
        values=np.asarray(values);vmax=float(np.max(values[mesh.leaf_mask])) if vmax is None else vmax
        colors=plt.get_cmap(cmap)(Normalize(vmin,max(vmax,vmin+1e-8))(values));colors[mesh.organ==STEM]=[.54,.40,.24,1]
    a=Poly3DCollection(mesh.triangles,facecolors=colors,edgecolors='none');ax.add_collection3d(a)
    lo=mesh.vertices.min(0);hi=mesh.vertices.max(0);span=max(float(np.max(hi-lo))*1.08,.02);center=(lo+hi)/2
    ax.set(xlim=(center[0]-span/2,center[0]+span/2),ylim=(center[1]-span/2,center[1]+span/2),zlim=(center[2]-span/2,center[2]+span/2),
        xlabel='East (m)',ylabel='North (m)',zlabel='Height (m)',title=title)
    ax.set_box_aspect((1,1,1));ax.set_proj_type('ortho');ax.view_init(elev=23,azim=-60);return a

def organs():
    from .geometry import Mesh
    fig=plt.figure(figsize=(10,4.6))
    for i,(v,f,label,organ) in enumerate([(*leaf(),'Original maize leaf / natural curvature',LEAF),(*stem(),'Tapered stem',STEM)]):
        # Shift the single organ only for display; canopy coordinates are untouched.
        vv=v.copy();vv[:,2]-=min(0,vv[:,2].min())
        m=Mesh(vv,f,np.full(len(f),organ),np.zeros(len(f),int),np.zeros(len(f),int),1)
        ax=fig.add_subplot(1,2,i+1,projection='3d');draw_mesh(ax,m,title=label)
    fig.tight_layout();return fig

def structures(configs):
    from .simulation import prepare_canopy
    fig=plt.figure(figsize=(4.5*len(configs),4.8))
    for j,(name,c) in enumerate(configs.items()):
        m=prepare_canopy(c).mesh;draw_mesh(fig.add_subplot(1,len(configs),j+1,projection='3d'),m,title=f'{name}: central crop; LAI={m.lai:.3f}')
    fig.tight_layout();return fig

def field_comparison(result,hour=12):
    i=int(np.argmin(abs(result.hours-hour)));m=result.mesh.mesh
    fig=plt.figure(figsize=(11,5))
    for j,(values,label,cmap,unit) in enumerate([(result.ppfd[i],'Leaf light','YlOrRd','PPFD'),(result.net_a[i],'Leaf net photosynthesis','viridis','umol CO2 / m2 leaf / s')]):
        q=values;low=min(0,float(q[m.leaf_mask].min()));high=float(q[m.leaf_mask].max())
        ax=fig.add_subplot(1,2,j+1,projection='3d');draw_mesh(ax,m,q,title=f'{label}: {result.hours[i]:.1f} h',cmap=cmap,vmin=low,vmax=high)
        fig.colorbar(ScalarMappable(norm=Normalize(low,max(high,low+1e-8)),cmap=cmap),ax=ax,shrink=.55,pad=.04,label=unit)
    fig.tight_layout();return fig

def daily_figure(results):
    fig,axes=plt.subplots(1,3,figsize=(13.5,4.1));names=list(results)
    for name,r in results.items():axes[0].plot(r.hours,r.canopy_a_ground,label=name)
    axes[0].set(xlabel='Clock hour',ylabel='umol CO2 / m2 ground / s',title='24-hour leaf net assimilation');axes[0].legend()
    for ax,key,title,color in [(axes[1],'daily_leaf_intercepted_mol_photons_m2_ground','Daily photons on leaves','#cf9b35'),
            (axes[2],'daily_net_mol_co2_m2_ground','Daily leaf net CO2','#288775')]:
        bars=ax.bar(names,[r.summary[key] for r in results.values()],color=color);ax.bar_label(bars,fmt='%.3f',padding=4)
        ax.set(title=title,ylabel='mol / m2 ground / day',ylim=(0,max(r.summary[key] for r in results.values())*1.2))
        ax.tick_params(axis='x',rotation=15)
    fig.tight_layout();return fig

def search_figure(records):
    lower=sorted({r['lower_angle'] for r in records});upper=sorted({r['upper_angle'] for r in records})
    z=np.array([[next(r['daily_net_mol_co2_m2_ground'] for r in records if r['lower_angle']==a and r['upper_angle']==b) for b in upper] for a in lower])
    fig,ax=plt.subplots(figsize=(6,4));im=ax.imshow(z,origin='lower',aspect='auto',cmap='YlGn')
    ax.set(xticks=range(len(upper)),xticklabels=upper,yticks=range(len(lower)),yticklabels=lower,
        xlabel='Upper angle above horizontal (deg)',ylabel='Lower angle (deg)',title='9 candidates: equal area and density')
    for i in range(len(lower)):
        for j in range(len(upper)):ax.text(j,i,f'{z[i,j]:.3f}',ha='center',va='center')
    fig.colorbar(im,ax=ax,label='mol CO2 / m2 ground / day');fig.tight_layout();return fig

def crop_figure(config=None):
    from .simulation import prepare_canopy
    p=prepare_canopy(config);fig=plt.figure(figsize=(11,4.8))
    ax=fig.add_subplot(121,projection='3d');a=draw_mesh(ax,p.source,title=f"Source stand: {p.report['source_rows']} x {p.report['source_columns']}")
    a.set_facecolor((.5,.55,.6,.15));a.set_alpha(.15)
    ax.add_collection3d(Poly3DCollection(p.triangles,facecolors='#389665',edgecolors='none'))
    x0,x1,y0,y1,z0,z1=p.domain
    for z in [z0,z1]:ax.plot([x0,x1,x1,x0,x0],[y0,y0,y1,y1,y0],[z]*5,c='#b84836',lw=1.4)
    for x,y in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]:ax.plot([x,x],[y,y],[z0,z1],c='#b84836',lw=1.2)
    ax.set_zlim(0,z1)
    draw_mesh(fig.add_subplot(122,projection='3d'),p.mesh,title=f"Simulate central {p.report['central_rows']} x {p.report['central_columns']} ground cell")
    fig.tight_layout();return fig
