"""Clip translated triangle copies into one XY periodic planting cell.

Total source surface area and organ/leaf identity are preserved. A triangle
crossing a wall is split, NOT discarded or counted twice. Source positions
remain available for whole-leaf visualization. Computations use the fragments.
"""
from dataclasses import dataclass
import itertools
import numpy as np
from .geometry import Mesh

@dataclass
class PeriodicMesh:
    mesh: Mesh
    source: Mesh
    source_face: np.ndarray
    domain: tuple
    report: dict

    def __getattr__(self,name):return getattr(self.mesh,name)

    def to_source(self,values):
        """Area-weight each fragment field back to the original source faces.
        Photosynthesis must be evaluated BEFORE this merge, since A(Q) is
        nonlinear. The merge is for visualization/analysis, not the solver.
        """
        q=np.asarray(values,dtype=float)
        if q.shape[-1]!=len(self.faces):raise ValueError('last axis must contain all prepared faces')
        flat=q.reshape(-1,q.shape[-1]);out=np.empty((len(flat),len(self.source.faces)))
        retained=np.bincount(self.source_face,weights=self.area,minlength=len(self.source.faces))
        for i,row in enumerate(flat):
            total=np.bincount(self.source_face,weights=row*self.area,minlength=len(self.source.faces))
            out[i]=np.divide(total,retained,out=np.full(len(retained),np.nan),where=retained>0)
        return out.reshape(q.shape[:-1]+(len(self.source.faces),))

def _clip(poly,axis,bound,greater):
    if not len(poly):return []
    out=[];a=poly[-1];ina=a[axis]>=bound if greater else a[axis]<=bound
    for b in poly:
        inb=b[axis]>=bound if greater else b[axis]<=bound
        if ina!=inb:
            t=(bound-a[axis])/(b[axis]-a[axis]);point=a+t*(b-a);point[axis]=bound;out.append(point)
        if inb:out.append(b.copy())
        a=b;ina=inb
    return out

def prepare_periodic(mesh,domain):
    b=np.asarray(domain,dtype=float)
    if b.shape!=(6,) or not np.isfinite(b).all() or np.any(b[1::2]<=b[::2]):raise ValueError('invalid periodic domain')
    if not len(mesh.faces):raise ValueError('empty canopy')
    if mesh.vertices[:,2].min()<b[4]-1e-12 or mesh.vertices[:,2].max()>b[5]+1e-12:
        raise ValueError('Z domain must contain every organ; raise the top boundary')
    source_area=mesh.area;vertices=[];parents=[];dropped=0.;slivers=0
    L=b[1::2]-b[::2]
    for face,t in enumerate(mesh.triangles):
        # Every translated image overlapping this cell is clipped exactly.
        ranges=[]
        for axis in range(2):
            k0=int(np.ceil((b[2*axis]-t[:,axis].max())/L[axis]))
            k1=int(np.floor((b[2*axis+1]-t[:,axis].min())/L[axis]))
            ranges.append(range(k0,k1+1))
        for ix,iy in itertools.product(*ranges):
            poly=[p.copy() for p in t+np.array([ix*L[0],iy*L[1],0.])]
            for axis,edge,greater in [(0,b[0],True),(0,b[1],False),(1,b[2],True),(1,b[3],False)]:
                poly=_clip(poly,axis,edge,greater)
            for j in range(1,len(poly)-1):
                tri=np.asarray([poly[0],poly[j],poly[j+1]])
                u=tri[1]-tri[0];v=tri[2]-tri[0];area=float(np.linalg.norm(np.cross(u,v))/2)
                if area<=1e-16:dropped+=area;continue
                # The original native engine uses Heron's area. Reject only
                # numerical zero-area fan slivers; report their lost area.
                lens=np.linalg.norm(tri[[1,2,0]]-tri,axis=1);s=lens.sum()/2
                heron=float(np.sqrt(abs(s*np.prod(s-lens))))
                if heron<=0:dropped+=area;continue
                if area<5e-7:slivers+=1
                vertices.extend(tri);parents.append(face)
    v=np.ascontiguousarray(vertices,dtype=float);f=np.arange(len(v),dtype=np.int32).reshape(-1,3)
    parent=np.asarray(parents,dtype=np.int32)
    prepared=Mesh(v,f,mesh.organ[parent],mesh.leaf_id[parent],mesh.plant_id[parent],float(L[0]*L[1]))
    per_source=np.bincount(parent,weights=prepared.area,minlength=len(mesh.faces))
    max_error=float(np.max(np.abs(per_source-source_area)))
    if not np.allclose(per_source,source_area,rtol=1e-10,atol=1e-13):
        raise ArithmeticError('periodic preparation failed to conserve each source face area')
    if not np.isclose(prepared.ground_area,mesh.ground_area,rtol=1e-12,atol=1e-14):
        raise ValueError('periodic cell ground area must equal the declared planting area')
    return PeriodicMesh(prepared,mesh,parent,tuple(b),dict(
        source_faces=len(mesh.faces),prepared_faces=len(f),source_leaf_area_m2=float(source_area[mesh.leaf_mask].sum()),
        prepared_leaf_area_m2=float(prepared.area[prepared.leaf_mask].sum()),max_source_face_area_error_m2=max_error,
        dropped_numerical_area_m2=dropped,small_fragments_area_below_5e_7_count=slivers,
        ground_area_m2=prepared.ground_area,lai=prepared.lai,
        algorithm='translate all overlapping images; Sutherland-Hodgman XY clipping; triangle fan; preserve source identity'))

def crop_center(mesh,domain):
    """Clip the central spatial cell out of a LARGER stand, without wrapping
    all source plants into that cell. Neighboring leaves entering the center
    are retained even when their stems are outside it. Periodic RAYS, rather
    than repeated copies of the entire large stand, are applied afterwards.
    """
    b=np.asarray(domain,dtype=float)
    if b.shape!=(6,) or not np.isfinite(b).all() or np.any(b[1::2]<=b[::2]):raise ValueError('invalid crop domain')
    if mesh.vertices[:,2].min()<b[4]-1e-12 or mesh.vertices[:,2].max()>b[5]+1e-12:raise ValueError('Z domain must contain all organs')
    tris=mesh.triangles;lo=tris.min(axis=1);hi=tris.max(axis=1)
    candidates=np.flatnonzero((hi[:,0]>=b[0])&(lo[:,0]<=b[1])&(hi[:,1]>=b[2])&(lo[:,1]<=b[3]))
    vertices=[];parents=[];dropped=0.;small=0
    for face in candidates:
        poly=[p.copy() for p in tris[face]]
        for axis,edge,greater in [(0,b[0],True),(0,b[1],False),(1,b[2],True),(1,b[3],False)]:poly=_clip(poly,axis,edge,greater)
        for j in range(1,len(poly)-1):
            t=np.asarray([poly[0],poly[j],poly[j+1]])
            area=float(np.linalg.norm(np.cross(t[1]-t[0],t[2]-t[0]))/2)
            lens=np.linalg.norm(t[[1,2,0]]-t,axis=1);s=lens.sum()/2
            heron=float(np.sqrt(abs(s*np.prod(s-lens))))
            if area<=1e-16 or heron<=0:dropped+=area;continue
            if area<5e-7:small+=1
            vertices.extend(t);parents.append(face)
    if not parents:raise ValueError('no canopy surface in crop cell')
    v=np.ascontiguousarray(vertices);f=np.arange(len(v),dtype=np.int32).reshape(-1,3);parent=np.asarray(parents,np.int32)
    prepared=Mesh(v,f,mesh.organ[parent],mesh.leaf_id[parent],mesh.plant_id[parent],float((b[1]-b[0])*(b[3]-b[2])))
    retained=np.bincount(parent,weights=prepared.area,minlength=len(mesh.faces))
    if np.any(retained>mesh.area+1e-12):raise ArithmeticError('central crop duplicated source area')
    return PeriodicMesh(prepared,mesh,parent,tuple(b),dict(
        region_mode='central_spatial_crop_from_larger_stand',source_faces=len(mesh.faces),prepared_faces=len(f),
        source_leaf_area_m2=float(mesh.area[mesh.leaf_mask].sum()),prepared_leaf_area_m2=float(prepared.area[prepared.leaf_mask].sum()),
        source_plants=int(len(np.unique(mesh.plant_id))),central_stem_plants=int(len(np.unique(prepared.plant_id[~prepared.leaf_mask]))),
        contributing_plants=int(len(np.unique(prepared.plant_id))),dropped_numerical_area_m2=dropped,
        small_fragments_area_below_5e_7_count=small,ground_area_m2=prepared.ground_area,lai=prepared.lai,
        algorithm='spatial clip of actual central cell; retain entering neighbor leaves; no periodic duplication of the large stand'))
