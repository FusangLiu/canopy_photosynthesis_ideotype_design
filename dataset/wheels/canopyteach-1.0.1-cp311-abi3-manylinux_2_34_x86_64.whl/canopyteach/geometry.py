"""Synthetic parametric organs; lengths in metres, azimuth CCW from east."""
from dataclasses import dataclass, asdict, replace
from pathlib import Path
import json
import numpy as np
from .maize import maize_leaf

LEAF, STEM = 1, 2

@dataclass(frozen=True)
class Architecture:
    height: float = 1.6
    stem_radius: float = .008
    leaves: int = 8
    leaf_length: float = .65
    leaf_width: float = .12
    droop: float = .06
    leaf_style: str = 'maize'
    curvature_deg: float = 70.
    mesh_step: float = .03
    wave_amplitude: float = 2.
    wave_cycles: int = 5
    seed: int = 20261025
    lower_angle: float = 20.
    upper_angle: float = 70.
    phyllotaxis: float = 180.
    rows: int = 3
    columns: int = 3
    dx: float = .32
    dy: float = .55
    row_rotation: float = 0.
    staggered: bool = False
    segments: int = 8
    plant_azimuth_mode: str = 'random'
    plant_azimuth_deg: float = 0.

    def __post_init__(self):
        positive=[self.height,self.stem_radius,self.leaf_length,self.leaf_width,self.dx,self.dy]
        if not np.isfinite(positive).all() or min(positive)<=0:
            raise ValueError('positive finite dimensions required')
        if self.stem_radius>=self.height/2: raise ValueError('stem radius too large')
        for n in (self.leaves,self.rows,self.columns,self.segments):
            if isinstance(n,bool) or int(n)!=n or n<1: raise ValueError('positive integer counts required')
        if self.segments<3: raise ValueError('segments >= 3 required')
        if self.leaf_style not in ('maize','simple'):raise ValueError('unknown leaf style')
        if not np.isfinite([self.curvature_deg,self.mesh_step,self.wave_amplitude]).all() or not 0<=self.curvature_deg<=140 or not 0<self.mesh_step<=self.leaf_length/4 or self.wave_amplitude<0:
            raise ValueError('invalid maize curvature/mesh/wave parameter')
        if int(self.wave_cycles)!=self.wave_cycles or self.wave_cycles<1 or int(self.seed)!=self.seed or self.seed<0:raise ValueError('invalid wave count or seed')
        if not np.isfinite([self.droop,self.lower_angle,self.upper_angle,self.phyllotaxis,self.row_rotation]).all():
            raise ValueError('nonfinite architecture parameter')
        if self.plant_azimuth_mode not in ('random','fixed') or not np.isfinite(self.plant_azimuth_deg):
            raise ValueError('plant azimuth mode must be random or fixed, with a finite fixed angle')
        if not 0<=self.droop<=self.height/4: raise ValueError('droop outside teaching range')
        if not 0<=min(self.lower_angle,self.upper_angle)<=max(self.lower_angle,self.upper_angle)<=85:
            raise ValueError('leaf angles must be in [0,85] degrees from horizontal')

    def save(self,path):
        Path(path).write_text(json.dumps(asdict(self),ensure_ascii=False,indent=2),encoding='utf-8')

    @classmethod
    def load(cls,path): return cls(**json.loads(Path(path).read_text(encoding='utf-8')))

@dataclass
class Mesh:
    vertices: np.ndarray
    faces: np.ndarray
    organ: np.ndarray
    leaf_id: np.ndarray
    plant_id: np.ndarray
    ground_area: float = 1.

    @property
    def triangles(self): return self.vertices[self.faces]
    @property
    def area(self):
        t=self.triangles
        return np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)/2
    @property
    def centers(self): return self.triangles.mean(axis=1)
    @property
    def leaf_mask(self): return self.organ==LEAF
    @property
    def lai(self): return float(self.area[self.leaf_mask].sum()/self.ground_area)

def leaf(length=.65,width=.12,droop=.06,angle=30.,azimuth=0.,segments=8,*,
         style='maize',curvature=70.,mesh_step=.03,wave_amplitude=2.,wave_cycles=5):
    """Default: supplied fspm_run_v3 local con_plant4 maize geometry.
    style='simple' retains the previous sine-width/parabolic teaching option.
    droop/segments affect only style='simple'; maize uses curvature/mesh_step.
    """
    if style=='maize':
        return maize_leaf(length,width,curvature,angle,azimuth,mesh_step,wave_amplitude,wave_cycles)
    if style!='simple':raise ValueError('unknown leaf style')
    if not length>0 or not width>0 or segments<3: raise ValueError('invalid leaf dimensions')
    vertices=[];row=[]
    for k,u in enumerate(np.linspace(0,1,segments+1)):
        ids=[]
        for v in ([0.] if k in (0,segments) else [-1.,0.,1.]):
            ids.append(len(vertices));vertices.append([length*u,width*v*np.sin(np.pi*u)/2,-droop*u*u])
        row.append(ids)
    faces=[]
    for a,b in zip(row[:-1],row[1:]):
        if len(a)==1:
            faces.extend([[a[0],b[j],b[j+1]] for j in range(2)])
        elif len(b)==1:
            faces.extend([[a[j],b[0],a[j+1]] for j in range(2)])
        else:
            for j in range(2): faces.extend([[a[j],b[j],b[j+1]],[a[j],b[j+1],a[j+1]]])
    alpha,psi=np.deg2rad([angle,azimuth])
    a=np.array([np.cos(alpha)*np.cos(psi),np.cos(alpha)*np.sin(psi),np.sin(alpha)])
    b=np.array([-np.sin(psi),np.cos(psi),0.])
    rotation=np.column_stack((a,b,np.cross(a,b)))
    return np.asarray(vertices)@rotation.T,np.asarray(faces,dtype=np.int32)

def stem(height=1.6,radius=.008,sides=10,taper=.4):
    theta=np.arange(sides)*2*np.pi/sides
    v=np.vstack([np.c_[r*np.cos(theta),r*np.sin(theta),np.full(sides,z)]
                 for r,z in [(radius,0),(radius*(1-taper),height)]])
    v=np.vstack([v,[0,0,0],[0,0,height]])
    f=[]
    for i in range(sides):
        j=(i+1)%sides
        f.extend([[i,j,sides+j],[i,sides+j,sides+i],
                  [2*sides,j,i],[2*sides+1,sides+i,sides+j]])
    return v,np.asarray(f,dtype=np.int32)

def plant_azimuth_grid(config,period=None):
    """One whole-plant Z rotation per planting position, repeated periodically.
    A separate seeded stream leaves the existing leaf-wave realization intact.
    period is (rows, columns) of the central simulation cell, not its buffer.
    """
    rows,columns=period or (config.rows,config.columns)
    if any(isinstance(n,bool) or int(n)!=n or n<1 for n in (rows,columns)):
        raise ValueError('azimuth period requires positive integer rows and columns')
    if config.plant_azimuth_mode=='fixed':return np.full((rows,columns),config.plant_azimuth_deg)
    stream=np.random.default_rng(np.random.SeedSequence([config.seed,0xA21]))
    return stream.uniform(0.,360.,size=(rows,columns))

def make_canopy(config=None,*,azimuth_period=None,azimuth_offset=(0,0)):
    config=config or Architecture()
    azimuths=plant_azimuth_grid(config,azimuth_period)
    oy,ox=azimuth_offset
    if any(isinstance(n,bool) or int(n)!=n for n in (oy,ox)):
        raise ValueError('azimuth offset requires integer row and column offsets')
    rng=np.random.default_rng(config.seed)
    cycles=np.maximum(1,config.wave_cycles+rng.integers(-1,2,config.leaves))
    amplitude=config.wave_amplitude*(.9+.2*rng.random(config.leaves))
    vertices=[];faces=[];organs=[];leaf_ids=[];plants=[];offset=0
    def add(v,f,organ,lid,pid):
        nonlocal offset
        vertices.append(v);faces.append(f+offset);offset+=len(v)
        organs.extend([organ]*len(f));leaf_ids.extend([lid]*len(f));plants.extend([pid]*len(f))
    psi=np.deg2rad(config.row_rotation)
    rotation=np.array([[np.cos(psi),-np.sin(psi),0],[np.sin(psi),np.cos(psi),0],[0,0,1.]])
    for iy in range(config.rows):
        for ix in range(config.columns):
            pid=iy*config.columns+ix
            phi=float(azimuths[(iy-oy)%azimuths.shape[0],(ix-ox)%azimuths.shape[1]])
            beta=np.deg2rad(phi)
            plant_rotation=np.array([[np.cos(beta),-np.sin(beta),0],[np.sin(beta),np.cos(beta),0],[0,0,1.]])
            position=np.array([(ix-(config.columns-1)/2)*config.dx+
                (.5*config.dx if config.staggered and iy%2 else 0),
                (iy-(config.rows-1)/2)*config.dy,0.])@rotation.T
            v,f=stem(config.height,config.stem_radius);add(v@plant_rotation.T+position,f,STEM,-1,pid)
            for k in range(config.leaves):
                fraction=k/max(config.leaves-1,1)
                angle=config.lower_angle+(config.upper_angle-config.lower_angle)*fraction
                v,f=leaf(config.leaf_length,config.leaf_width,config.droop,angle,
                         k*config.phyllotaxis+config.row_rotation+phi,config.segments,
                         style=config.leaf_style,curvature=config.curvature_deg,mesh_step=config.mesh_step,
                         wave_amplitude=amplitude[k],wave_cycles=int(cycles[k]))
                base=position+np.array([0,0,config.height*(k+1)/(config.leaves+1)])
                add(v+base,f,LEAF,pid*config.leaves+k,pid)
    mesh=Mesh(np.ascontiguousarray(np.vstack(vertices)),np.ascontiguousarray(np.vstack(faces),dtype=np.int32),
        np.asarray(organs,dtype=np.int8),np.asarray(leaf_ids,dtype=np.int32),np.asarray(plants,dtype=np.int32),
        config.rows*config.columns*config.dx*config.dy)
    if np.any(mesh.area<=1e-16) or mesh.vertices[:,2].min()<-1e-10:
        raise ValueError('degenerate organ or leaf below ground; reduce curvature or raise lowest node height')
    return mesh

def presets(base=None):
    base=base or Architecture()
    return {'flat':replace(base,lower_angle=15,upper_angle=15),
            'erect':replace(base,lower_angle=75,upper_angle=75),
            'layered':replace(base,lower_angle=20,upper_angle=70)}

