from pathlib import Path
import json,csv
import numpy as np

def save_day(result,folder):
    p=Path(folder);p.mkdir(parents=True,exist_ok=True);r=result;m=r.mesh
    (p/'summary.json').write_text(json.dumps(r.summary,indent=2,ensure_ascii=False),encoding='utf-8')
    np.savez_compressed(p/'arrays.npz',hours=r.hours,sun=r.sun,direct_normal=r.direct_normal,ppfd=r.ppfd,
        net_a=r.net_a,canopy_a_ground=r.canopy_a_ground,daily_light_leaf=r.daily_light_leaf,daily_carbon_leaf=r.daily_carbon_leaf,
        vertices=m.vertices,faces=m.faces,organ=m.organ,source_face=m.source_face,source_vertices=m.source.vertices,
        source_faces=m.source.faces,source_organ=m.source.organ,source_plant_id=m.source.plant_id,
        plant_id=m.plant_id,leaf_id=m.leaf_id,source_ground_area=m.source.ground_area,area=m.area,domain=m.domain)
    np.savetxt(p/'time_series.csv',np.c_[r.hours,r.sun,r.direct_normal,r.canopy_a_ground,
        [s['leaf_umol_s']/m.ground_area for s in r.statistics],
        [s['stem_umol_s']/m.ground_area for s in r.statistics],
        [s['escape_umol_s']/m.ground_area for s in r.statistics]],delimiter=',',
        header='clock_hour,sun_east,sun_north,sun_up,DNI,leaf_net_CO2_per_ground,leaf_photons_per_ground,stem_photons_per_ground,escape_photons_per_ground',comments='')
    noon=int(np.argmin(abs(r.hours-12)))
    np.savetxt(p/'per_fragment.csv',np.c_[np.arange(len(m.faces)),m.source_face,m.organ,m.leaf_id,m.area,
        r.ppfd[noon],r.net_a[noon],r.daily_light_leaf,r.daily_carbon_leaf],delimiter=',',
        header='fragment,source_face,organ,leaf_id,area_m2,noon_PPFD,noon_A,daily_photons_mol_m2_face,daily_CO2_mol_m2_face',comments='')
    return p

def save_comparison(results,path):
    rows=[dict(name=name,**r.summary) for name,r in results.items()]
    keys=['name','lai','ground_area_m2','daily_leaf_intercepted_mol_photons_m2_ground','daily_net_mol_co2_m2_ground','daily_leaf_interception_fraction']
    with Path(path).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,keys,extrasaction='ignore');w.writeheader();w.writerows(rows)

