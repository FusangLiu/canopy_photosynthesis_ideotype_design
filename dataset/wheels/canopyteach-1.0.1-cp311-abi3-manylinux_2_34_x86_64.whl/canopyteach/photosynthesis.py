"""Steady-state nonrectangular A-Q curve; fixed leaf physiology for all organs."""
from dataclasses import dataclass
import numpy as np

@dataclass(frozen=True)
class Physiology:
    alpha: float = .05
    pmax: float = 30.
    theta: float = .7
    rd: float = 1.
    def __post_init__(self):
        if not np.isfinite([self.alpha,self.pmax,self.theta,self.rd]).all() or self.alpha<=0 or self.pmax<=0 or not 0<self.theta<=1 or self.rd<0:
            raise ValueError('invalid A-Q parameters')

def assimilation(q,physiology=None):
    p=physiology or Physiology();q=np.asarray(q,dtype=float)
    if not np.isfinite(q).all() or np.any(q<0): raise ValueError('nonnegative finite incident PPFD required')
    x=p.alpha*q;s=x+p.pmax
    # Rationalized form avoids cancellation at low light; Pmax is GROSS asymptote.
    return 2*x*p.pmax/(s+np.sqrt(np.maximum(s*s-4*p.theta*x*p.pmax,0.)))-p.rd

